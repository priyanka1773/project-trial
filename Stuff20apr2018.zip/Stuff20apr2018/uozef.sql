-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Apr 19, 2018 at 11:23 PM
-- Server version: 5.6.39-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `uozef`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(255) NOT NULL,
  `admin_username` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_mobile_no` bigint(51) NOT NULL,
  `admin_active_inactive` tinyint(4) NOT NULL DEFAULT '1',
  `admin_created_date` date NOT NULL,
  `admin_modify_date` date NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_username`, `admin_password`, `admin_email`, `admin_mobile_no`, `admin_active_inactive`, `admin_created_date`, `admin_modify_date`) VALUES
(1, 'admin', 'admin', '0192023a7bbd73250516f069df18b500', 'admin@gmail.com', 1, 1, '2018-03-20', '2018-03-21');

-- --------------------------------------------------------

--
-- Table structure for table `forgotpassword`
--

CREATE TABLE IF NOT EXISTS `forgotpassword` (
  `forgot_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) NOT NULL,
  `user_token` text NOT NULL,
  `created_date` varchar(255) NOT NULL,
  `CreateTime` varchar(255) NOT NULL,
  `ExpiryTime` varchar(255) NOT NULL,
  PRIMARY KEY (`forgot_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `record_coin`
--

CREATE TABLE IF NOT EXISTS `record_coin` (
  `coin_id` int(11) NOT NULL,
  `coin_sold` varchar(255) NOT NULL,
  `coin_available` varchar(255) NOT NULL,
  `coin_total` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`coin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `record_coin`
--

INSERT INTO `record_coin` (`coin_id`, `coin_sold`, `coin_available`, `coin_total`, `status`, `created_date`, `modify_date`) VALUES
(1, '285714288', '714285712', '1000000000', 1, '2018-03-24 03:02:29', '2018-03-24 03:02:29');

-- --------------------------------------------------------

--
-- Table structure for table `token_supply`
--

CREATE TABLE IF NOT EXISTS `token_supply` (
  `token_supply_id` int(11) NOT NULL AUTO_INCREMENT,
  `token_supply_name` varchar(255) NOT NULL,
  `token_supply_from_qty` varchar(255) NOT NULL,
  `token_supply_to_qty` varchar(255) NOT NULL,
  `token_supply_price` varchar(255) NOT NULL,
  `token_supply_total_qty` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_date` date NOT NULL,
  `modify_date` date NOT NULL,
  PRIMARY KEY (`token_supply_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `token_supply`
--

INSERT INTO `token_supply` (`token_supply_id`, `token_supply_name`, `token_supply_from_qty`, `token_supply_to_qty`, `token_supply_price`, `token_supply_total_qty`, `status`, `created_date`, `modify_date`) VALUES
(1, 'Round1', '1', '285714287', '0.10', '285714287', 1, '2018-03-23', '2018-04-05'),
(2, 'Round1', '285714288', '523809524', '0.20', '523809524', 1, '2018-03-24', '2018-04-05'),
(3, 'Round3', '523809525', '714285715', '0.40', '714285715', 1, '2018-03-24', '2018-04-05'),
(4, 'Round4', '714285716', '857142859', '0.80', '857142859', 1, '2018-03-24', '2018-04-05'),
(5, 'Round5', '857142860', '952380955', '1.60', '952380955', 1, '2018-03-24', '2018-04-05'),
(6, 'Round6', '952380956', '1000000000', '3.20', '1000000000', 1, '2018-03-24', '2018-04-05');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `orderId` text NOT NULL,
  `pair` varchar(255) NOT NULL,
  `withdrawal` text NOT NULL,
  `withdrawalAmount` varchar(255) NOT NULL,
  `deposit` text NOT NULL,
  `depositAmount` varchar(255) NOT NULL,
  `expiration` varchar(255) NOT NULL,
  `quotedRate` varchar(255) NOT NULL,
  `maxLimit` varchar(255) NOT NULL,
  `returnAddress` text NOT NULL,
  `apiPubKey` longtext NOT NULL,
  `minerFee` varchar(255) NOT NULL,
  `payment_status` tinyint(4) NOT NULL DEFAULT '0',
  `created_date` date NOT NULL,
  `time` varchar(45) NOT NULL,
  `modify_date` date NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=107 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `user_id`, `orderId`, `pair`, `withdrawal`, `withdrawalAmount`, `deposit`, `depositAmount`, `expiration`, `quotedRate`, `maxLimit`, `returnAddress`, `apiPubKey`, `minerFee`, `payment_status`, `created_date`, `time`, `modify_date`) VALUES
(1, 1, '3281ff46-ee86-4385-a7f0-240c8ce36339', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x9118c0757af7209a15b2c088d1c7fc0ae5a9fa55', '0.18749519', '1522437410034', '0.05546809', '13.19289082', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(3, 1, '29de85c1-c83c-489b-81f5-ff08faa77631', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x2c78ec6c288443128c65c07092ed32ced521706c', '0.18655957', '1522441016437', '0.05574627', '13.11708899', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(4, 1, 'df3791c8-4d8d-49cb-acfd-63828445920f', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x37d04b24c7f96a7f462018d280c2f8c97335c975', '0.18662274', '1522441110036', '0.0557274', '13.14507552', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(5, 3, '50fc978f-d873-465e-8594-05a2f655761b', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0xc583b95f89d5fa2a2002a969dc82a1a580eb0873', '0.17899904', '1522462102155', '0.05810087', '12.07282976', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(6, 3, '0b95ed7c-cb41-4c4f-9291-7ab134c643e9', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x818bb70e5a71c6756b2cb433b6c8d892eb6c5bd4', '0.17742448', '1522462944584', '0.05861649', '11.94435495', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(7, 3, 'b550b8df-f8a9-43f8-9e42-ec7b5776ffdf', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x9e7739fff2ab6a08520fc7f0a8b250a1508b9dc4', '0.17967189', '1522471091327', '0.05788329', '12.24425541', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(8, 3, 'f7b914a2-ccbc-4ab9-85a3-f30d43e13a3d', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x32ba8a74eefce5834ede5b155131d81726a824b4', '0.1795794', '1522471162236', '0.0579131', '12.20709624', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(9, 3, '6c16af57-064f-4132-9d6b-974d2ab2372e', 'bch_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '12pXNN8kF8LVMCNdWfQuboKA6MnD2D8JqF', '0.1028396', '1522475963446', '0.10112836', '7.08881353', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(10, 3, '446d3871-4228-4311-a0d0-7babeb7c45d0', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x367871eec9e76b883d385c48346bea0f52c9aeb6', '0.18156349', '1522476078751', '0.05728024', '12.5324657', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(11, 3, '8023337a-e053-4c90-a369-096c5a9860a6', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '35RZg3FFG9yvhauvoMu6TGgreu2ds9W9Te', '0.00064268', '1522478100525', '17.27135232', '0.72258303', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(12, 3, '0947f0f6-c56f-46af-bf86-65f67172e5e2', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3DB364qCuywUAXTnjp9DvDmXzVTNkKeaot', '0.00064268', '1522478711302', '17.27135232', '0.72465343', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(13, 3, 'e82eebd3-8ec7-45bf-ac45-54e2a358cdee', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x456bc82c3e778ab159a95730cae9490c02d43185', '0.18195799', '1522478803657', '0.05715605', '12.58885715', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(14, 3, '01ea1b56-4333-4018-b39f-87eccd969a9f', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', 'LT5WzWPc7hdHbnYTWjDhZejRPFbWCnb8ef', '0.0376263', '1522478862823', '0.29500641', '42.18635446', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(15, 3, '79265dbc-6214-4b91-b0fb-aef1d3e39168', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '33Y9NTgP2ubRkRAxRLQx2KJ6Z3EWtywF4A', '0.00064411', '1522479007046', '17.23300549', '0.72451798', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(16, 3, '5722372a-58c0-4ccf-b516-d405de023198', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '35xRu5kTTXLAkYLFkrDHDrDwvN2YetNp2o', '0.00064141', '1522481041127', '17.30564894', '0.73200548', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(17, 3, '296e2b8c-6a84-4ab6-9c74-9a42afbd220e', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3AenpE9Jz7yeVgdNkaZ1q2XB5EkkqXWK8j', '0.00064129', '1522481144184', '17.30896546', '0.73093324', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(18, 1, 'be6595c3-d775-4e33-8281-1386f57cbd33', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3JVSQTSicJJe9UtAtUBJvDyBKK2ScHVm6D', '0.00064134', '1522481297921', '17.30745779', '0.73089584', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(19, 1, '601dbe87-4002-4ad9-ac3b-e6f3aa49489d', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3M1XdHtLWYCFeAXZTjGKTbU663MaZjZCpG', '0.0006412', '1522481390235', '17.31137828', '0.73080504', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(20, 1, 'fa4aa5b8-367e-4129-afdf-a2eb60f60d63', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3E8N7jjqKC2F1K7pu5AFn5x2XKhZQue6j5', '0.00064052', '1522481696895', '17.32979818', '0.73217162', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(21, 3, '0a696b9d-8cd6-4d69-bcbb-91bcdddeb4e1', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3Fdao6U1XXZDZ3sCrd9dHu1ghqaVe3VQ4T', '0.0006403', '1522486425922', '17.33554353', '0.72178298', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(22, 3, '494a4d16-c1ff-43ba-bac9-cc2b0c7876b7', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3Ld19Jpa7otBcMAk5MnxGrjE2AZX1T1b7y', '0.00064074', '1522486481949', '17.32375455', '0.72166422', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(23, 3, '0202e862-136b-4d8e-b44c-62aec97bdba8', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '33Num6DfW8Ysu58oTz958S118LiFJrFwTx', '0.00064045', '1522486544447', '17.33161209', '0.72029192', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(24, 3, '268471e0-62d5-4824-8055-220fe9d22847', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3MkQ3cf795wzqX6KB7ikuVtNBvN8PxmWxF', '0.00064046', '1522487916757', '17.33130974', '0.72339533', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(25, 4, 'feb082b0-243c-4b16-a753-f0cc59726714', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3BuqLNuFZSnL6fm8vSEZdzvXzm8K6ewLJT', '0.00064035', '1522488434267', '17.33433367', '0.72248593', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(26, 3, '1af7be7f-8201-44d3-8196-1b336b251177', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x4d4f4a92550a3d9df726fe9ce5167e338897c432', '0.18268517', '1522490175863', '0.05692854', '12.52493103', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(27, 3, '8be1f37f-e47b-467a-8d1b-0c0b7eb03c85', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3DTgpXUzBW2fmirrXsUNhg7NbLj1EUCnGA', '0.00064033', '1522490645425', '17.33493858', '0.71567617', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(28, 3, '7481b7b6-c005-40f9-9f30-affb68ffd4e3', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3Dassn9UYherzA1NCseJzLwXEW9hDw7njN', '0.00064031', '1522490778726', '17.33524105', '0.71324438', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(29, 3, '5345bc0b-a0eb-4cdc-b64f-18b42d7c75f8', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '3LTxYge76YsoHwrY2UsmGMbr8qLfUWJ6cD', '0.00064056', '1522490827721', '17.32858911', '0.71362714', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-03-31', '', '2018-03-31'),
(30, 3, '7c1f80ea-5af1-44f4-92e0-17e9243f0a48', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x21224fd1b3b987541748b82852ab7894d407c352', '0.18263974', '1522491525867', '0.0569427', '12.44210783', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(31, 3, 'c483875c-defe-4936-ae1c-fdbcd36d9fcc', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x530f8c4c0aec13032e0dd4bcb0f0646c43914049', '0.18350654', '1522491990745', '0.05667373', '12.5296084', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-03-31', '', '2018-03-31'),
(32, 22, '72c1d76a-bbf7-4381-8c35-bac486228453', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '2.01', 'LgnT3KeC9tuBF93NwoyrjvkAghbv6Vwbjv', '6.5782142', '1522733584286', '0.30572127', '41.01250202', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-04-03', '', '2018-04-03'),
(33, 22, '95547d5b-43b4-4679-bbef-ae84cabf4769', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '2.01', 'Ldp2m844HJ6oQWdQ1XRCWu1HVYyX3DGtSJ', '6.57615825', '1522733634359', '0.30581685', '40.99025685', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-04-03', '', '2018-04-03'),
(34, 3, '0f624e22-c6d8-4ffb-a451-ed6fef1e39a0', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', 'LapQG9nUZ8qpuGSuJJ2qoerCPDj6nvpVgj', '0.03634245', '1522734301253', '0.30542796', '40.83834974', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-04-03', '', '2018-04-03'),
(35, 4, 'c46936f1-ab22-409e-9052-52e1188accde', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.05', 'LV4awrqYFSYHh2vdkWkj58avRnrWcNrq7P', '0.16661501', '1522735116651', '0.30669505', '40.91622947', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-04-03', '', '2018-04-03'),
(36, 4, '41e72521-5b88-4fb3-83fb-955555e74763', 'bch_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '1HewC4H5Hfvd9FhB8zYJ5SCnzrNhQfyrMN', '0.00646101', '1522735300087', '1.71799855', '7.31542503', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0011', 0, '2018-04-03', '', '2018-04-03'),
(37, 0, '8979b792-aee6-4cba-8733-524bf127926f', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0xf9679c82e535d3752d486bdef66991feabf0e4a3', '0.19251145', '1522753187845', '0.05402276', '12.58753174', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-04-03', '', '2018-04-03'),
(38, 3, '18181273-1a8b-430e-acf0-e955dde74f9d', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x9212c319e88b26a040e5bc2bc11c65a79dd2df4a', '0.19133038', '1522767159369', '0.05435624', '12.42113878', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-04-03', '', '2018-04-03'),
(39, 3, 'f43145ed-47c3-424b-a9a1-f9227eb1dd62', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x94289a3310655ea767f486be8b05317b7cbdaccb', '0.1914527', '1522767745959', '0.05432151', '12.43076314', '', '35c00d98f002ce59b9713bd2a2b508f74434f30f6e4e9717241745f10e7ddd238cd62b38c5d361c473295b98e58531868bb5f0bd3e47a409bf5a7d27c229c9df', '0.0004', 0, '2018-04-03', '', '2018-04-03'),
(40, 3, '9ebd87c8-767c-4b2a-a1a8-0b03bfd30223', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x79eab4e360fd1d99908883cb5c20bd1f1e59a9e3', '0.19145972', '1522769664502', '0.05431952', '12.37500031', '', 'fakeApiKeyJustHereForTestingv2', '0.0004', 0, '2018-04-03', '', '2018-04-03'),
(41, 3, 'e32987a0-45ee-45b8-be04-7b5e545f77e6', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0x0926c23e1d4b107fda1b049898916fafa8c869b5', '0.19141426', '1522770726312', '0.05433242', '12.38289436', '', 'fakeApiKeyJustHereForTestingv2', '0.0004', 0, '2018-04-03', '', '2018-04-03'),
(42, 3, 'e774cba6-5250-49fa-ba3d-7b1309f31796', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.01', '33R5pYPCfiS3SaVGe37MUqXJogEs1pSfpe', '0.00061316', '1522777059008', '18.10280424', '0.67706916', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-03', '', '2018-04-03'),
(43, 3, 'b80cdeb5-6aa3-40f2-8486-5df158fa7cb0', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0xd39c438b026920e44c6362e074376e3e4d8c2385', '0.19122857', '1522779804311', '0.05438518', '12.28753454', '', 'fakeApiKeyJustHereForTestingv2', '0.0004', 0, '2018-04-03', '23:48:26', '2018-04-03'),
(45, 1, 'adbd3261-c381-4b3c-a330-501c4df3bd54', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.01', '0xca9a4f04f867cd2c5793bfad048bf64387d472b3', '0.18925446', '1522783310005', '0.05495247', '12.08966371', '', 'fakeApiKeyJustHereForTestingv2', '0.0004', 0, '2018-04-04', '00:46:50', '2018-04-04'),
(71, 4, '9e36ee15-fda5-43f8-944d-e24ee84fa336', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', 'LLr6CLHThMiJoMbmJA8nsKfA85iaQ2ceF6', '0.31955747', '1522827259512', '0.31637502', '38.34507744', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-04', '12:59:20', '2018-04-04'),
(72, 4, '58da5510-e816-48b4-848f-b1e87cec82d7', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', 'LPVpKLM8bze1a9FzemFmvkyxQxWfaBT8tC', '0.3201765', '1522831174175', '0.31576334', '38.47353633', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-04', '14:04:34', '2018-04-04'),
(73, 4, '10e2281f-4f12-4ef6-a3d9-476df303a1bd', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', 'LWdqM2WX7hXkXQ5qPT5nEYfmrKzXuCggFV', '0.3201765', '1522831174295', '0.31576334', '38.47353633', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-04', '14:04:35', '2018-04-04'),
(80, 3, '366352e9-4fde-4e5e-be2d-f3d6ee35de78', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', 'Lf1ZmNKia2KBZW9raUNvHXQ8oQ3WP4MeCy', '0.3195463', '1522833084285', '0.31638608', '38.65090542', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-04', '14:36:24', '2018-04-04'),
(81, 3, '84d9591c-7db3-4ec9-9303-199df925fd97', 'ltc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', 'LQmNFiESFU5JxC1zhDQWhdmAqu9Pht68yq', '0.31996767', '1522833325501', '0.31596942', '38.73241304', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-04', '14:40:26', '2018-04-04'),
(82, 4, '99048cda-c986-4e96-8659-18058e23d79e', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '34ekyjmeyDUL16kfRH6483wBosp8oyuf8n', '0.00565254', '1522894876150', '17.8857544', '0.75363402', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-05', '07:46:16', '2018-04-05'),
(83, 4, '154c2b3c-4d13-46c0-9df1-17e262e9dc46', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '3BX3DvvnkDyNDr37PjUJbEmNcmDSbNLy1v', '0.00565254', '1522894876151', '17.8857544', '0.75363402', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-05', '07:46:16', '2018-04-05'),
(84, 4, '28e24144-6d49-47d7-9f22-cf54b2964fb2', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '3M5XEBEBMyMS6fdrya62WeHX7HZHMx8FEC', '0.00565254', '1522894883628', '17.8857544', '0.75363402', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-05', '07:46:23', '2018-04-05'),
(85, 4, 'ece81361-84a4-4f5f-bbc3-ec74427cd9e0', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '3HVwmVzsbLfSywC2tkb9qKvyPGoBcTitST', '0.00565254', '1522894883621', '17.8857544', '0.75363402', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-05', '07:46:24', '2018-04-05'),
(96, 3, 'b0447436-0ec9-4f05-a9d0-d857ad20b540', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '3E9QtmUNH8B1zYKyudAdfyAqmHJMT5BdyZ', '0.0057253', '1522942047542', '17.65845508', '0.74227367', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-05', '20:52:27', '2018-04-05'),
(97, 3, 'e39ab00f-fcc3-4cfd-9754-e1e29feaac7e', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.1', '0xd172a29e8815c557be71cfe6f1db86a62268664e', '1.79672539', '1522942158190', '0.05579595', '13.24902662', '', 'fakeApiKeyJustHereForTestingv2', '0.00025', 0, '2018-04-05', '20:54:18', '2018-04-05'),
(98, 3, 'beff82e3-ba97-4d62-9ac5-26e33efb2fe2', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.1', '0xc793b0275ee60fc9314a3422f3313dcaf53f95e0', '1.80967916', '1522992543133', '0.05539656', '13.13364019', '', 'fakeApiKeyJustHereForTestingv2', '0.00025', 0, '2018-04-06', '10:54:03', '2018-04-06'),
(101, 3, '9b2e1342-a30b-42ea-b080-cdd4890c2769', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '17t3pan6kgpCij6xBrcDxhraRsS7k23rdK', '0.00567422', '1522993891659', '17.81743185', '0.73665042', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-06', '11:16:32', '2018-04-06'),
(102, 4, '4ddcc478-3ac7-4f0b-a78e-67fe22d11cf1', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '3FL6vEfQzMSWSLpHfuGED964qfD4trtD81', '0.00564888', '1523068765329', '17.89735367', '0.73034389', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-07', '08:04:25', '2018-04-07'),
(103, 3, 'ebc4d52e-11f9-42a3-b0c0-95abd7986b0e', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.1', '0x85c9d76c5b76d124cb14b3be46865f57c74ef6d2', '1.73679237', '1523283077476', '0.05772135', '12.85516371', '', 'fakeApiKeyJustHereForTestingv2', '0.00025', 0, '2018-04-09', '19:36:19', '2018-04-09'),
(104, 3, 'f332ea2c-e211-4648-9cbe-6b7097cff359', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '3NpXrP63BxqiXRjaVj832uVXtZKMmxeBUk', '0.00601227', '1523345113576', '16.81561219', '0.74097127', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-10', '12:50:15', '2018-04-10'),
(105, 3, '6531ff0e-d2c7-4a5f-b199-8ab24c763873', 'eth_btc', '1HRhypwYocUXXiqGYTaDBUgBFsVErZep1e', '0.1', '0x5d483648bc392827d61fd68b6ba381df8d4b4471', '1.65814614', '1523434629201', '0.06048924', '11.93736682', '', 'fakeApiKeyJustHereForTestingv2', '0.0003', 0, '2018-04-11', '13:42:09', '2018-04-11'),
(106, 4, '62541f23-df17-4d20-bcab-b21ef7e1ef74', 'btc_eth', '0xb8900b5dd385b856094b2f23169ca2d156b6178d', '0.1', '3MxESdJiHdApj4tw3SMa7B994FPivqNyZS', '0.00643031', '1523940711745', '15.72242443', '0.62329373', '', 'fakeApiKeyJustHereForTestingv2', '0.0011', 0, '2018-04-17', '10:16:52', '2018-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(255) NOT NULL,
  `user_lname` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_referral_code` varchar(255) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `mailSent` tinyint(4) NOT NULL,
  `verify_status` tinyint(4) NOT NULL,
  `user_token` longtext NOT NULL,
  `ExpiryTime` varchar(245) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_fname`, `user_lname`, `user_image`, `user_email`, `user_password`, `user_referral_code`, `isActive`, `mailSent`, `verify_status`, `user_token`, `ExpiryTime`) VALUES
(3, 'bharat', 'chhabra', '', 'bharatchhabra13@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'f98640886614cfbd2ac738872b21c6bf51e3a451', 1, 1, 1, 'd0ea84972866f3aa7b6da52d6e30c25a99430aa4', ''),
(4, 'priyanka', 'patel', '', 'priyanka.jigar91@gmail.com', 'c53255317bb11707d0f614696b3ce6f221d0e2f2', '5291632df0edc328771cee7895b769a0bd512ca2', 1, 1, 1, '76248acd78f7cab79d602b41e44bc6680ee25366', ''),
(17, 'Bharat', 'Chhabra', '', 'bharatchhabra09@gmail.com', 'e02ca98305c88a0c4af008d40e3961537d555066', '3aee732ad1f6a4a0e98acb8ef77083b94f4d563f', 1, 1, 1, '7ed7395f0fc59db5b592736d9a16ccde194c1ca6', ''),
(20, 'jigna', 'Sheth', '', 'jignasheth407@gmail.com', 'e02ca98305c88a0c4af008d40e3961537d555066', '418c81f4a7ed92c35af871da45ed40712761034a', 1, 1, 1, 'eefcf6f020a8b589e058df36649c175665e2d7e7', ''),
(22, 'tom', 'peter', '', 'tom123@gmail.com', '1fae3ce0905862435d03af3ce72aa80d4463f445', 'faade724980d98df3d547375eaf1ad5303e157e5', 1, 1, 1, 'e36b0f2d26a03d974e4feac42bfd3d24f74f7fd2', ''),
(23, 'pavan', 'prajapat', '', 'pavan@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '25c0cfecedc67c64fa1e4f4aaa94fa52bc1df3bd', 1, 1, 1, '4c631b8e5d750193a2d78ea870f97bb6f82a4ec2', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
